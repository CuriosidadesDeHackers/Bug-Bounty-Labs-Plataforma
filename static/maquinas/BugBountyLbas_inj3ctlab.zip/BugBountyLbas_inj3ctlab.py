import os
import subprocess
import signal
import sys
import time

def ejecutar_comando(comando):
    """Ejecuta un comando en la terminal y devuelve la salida."""
    try:
        resultado = subprocess.run(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        return resultado.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.strip()}")
        return None

def descargar_imagen_docker_con_progreso(nombre_imagen):
    print(f"\033[1;37mDescargando la máquina {nombre_maquina}, espere por favor...\n\033[0m")
    
    tiempo_inicial = time.time()
    proceso = subprocess.Popen(["docker", "pull", nombre_imagen], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    longitud_barra_progreso = 40
    while proceso.poll() is None:
        tiempo_transcurrido = time.time() - tiempo_inicial
        progreso = min(int(tiempo_transcurrido * 10), 100)
        barra_completada = int(longitud_barra_progreso * progreso / 100)
        barra = "#" * barra_completada + "-" * (longitud_barra_progreso - barra_completada)
        print(f"\r[\033[1;32m{barra}\033[0m] {progreso}%", end="")
        time.sleep(0.1)

    proceso.communicate()  
    barra_final = "#" * longitud_barra_progreso
    print(f"\r[\033[1;32m{barra_final}\033[0m] 100%", end="")
    print("\n\033[1;37mDescarga completa.\033[0m")

def iniciar_contenedor(nombre_imagen):
    id_contenedor = ejecutar_comando(["docker", "run", "-d", nombre_imagen])
    return id_contenedor

def obtener_ip_contenedor(id_contenedor):
    ip = ejecutar_comando(["docker", "inspect", "-f", "{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}", id_contenedor])
    print(f"\033[1;32mLa IP de la máquina {nombre_maquina} es -> \033[1;37m{ip}\n\033[0m")
    return ip

def eliminar_contenedores(nombre_imagen):
    contenedores = ejecutar_comando(["docker", "ps", "-a", "--filter", f"ancestor={nombre_imagen}", "-q"])
    if contenedores:
        print(f"\033[1;33mParalizando la máquina {nombre_maquina}...\033[0m")
        for id_contenedor in contenedores.split("\n"):
            ejecutar_comando(["docker", "rm", "-f", id_contenedor])

def eliminar_imagen(nombre_imagen):
    print(f"\033[1;33mEliminando la máquina {nombre_maquina}...\033[0m")
    ejecutar_comando(["docker", "rmi", "-f", nombre_imagen])

def verificar_imagen_existente(nombre_imagen):
    return ejecutar_comando(["docker", "images", "-q", nombre_imagen])

def manejar_salida(señal, marco):
    print("\n\033[1;31mDetectado Ctrl+C. Limpiando...\033[0m")
    
    eliminar_contenedores(nombre_imagen)
    print("\033[1;32mLa máquina ha sido detenida.\033[0m")
    
    while True:
        eliminar_imagen_completa = input(f"\033[1;37m¿Quieres eliminar por completo la máquina {nombre_maquina}? (s/n):\033[0m").strip().lower()
        if eliminar_imagen_completa == 's':
            eliminar_imagen(nombre_imagen)
            print("\033[1;32mLa máquina ha sido eliminada por completo.\033[0m")
            break
        elif eliminar_imagen_completa == 'n':
            print(f"\033[1;33mSe ha conservado la máquina {nombre_maquina}.\033[0m")
            break
        else:
            print("\033[1;31mEntrada no válida. Por favor, responde 's' o 'n'.\033[0m")
    
    sys.exit(0)

if __name__ == "__main__":
    if os.geteuid() != 0:
        print("\033[1;31mDebes ser root para ejecutar este script.\033[0m")
        sys.exit(1)

    nombre_maquina = "inj3ctlab"

    nombre_imagen = f"bugbountylabs/{nombre_maquina}"

    try:
        print("""
██████╗ ██╗   ██╗ ██████╗     ██████╗  ██████╗ ██╗   ██╗███╗   ██╗████████╗██╗   ██╗    ██╗      █████╗ ██████╗ ███████╗
██╔══██╗██║   ██║██╔════╝     ██╔══██╗██╔═══██╗██║   ██║████╗  ██║╚══██╔══╝╚██╗ ██╔╝    ██║     ██╔══██╗██╔══██╗██╔════╝
██████╔╝██║   ██║██║  ███╗    ██████╔╝██║   ██║██║   ██║██╔██╗ ██║   ██║    ╚████╔╝     ██║     ███████║██████╔╝███████╗
██╔══██╗██║   ██║██║   ██║    ██╔══██╗██║   ██║██║   ██║██║╚██╗██║   ██║     ╚██╔╝      ██║     ██╔══██║██╔══██╗╚════██║
██████╔╝╚██████╔╝╚██████╔╝    ██████╔╝╚██████╔╝╚██████╔╝██║ ╚████║   ██║      ██║       ███████╗██║  ██║██████╔╝███████║
╚═════╝  ╚═════╝  ╚═════╝     ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝   ╚═╝      ╚═╝       ╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝
        """)

        print("\033[1;33mFundadores\033[0m")
        print("\033[1;37mEl Pingüino de Mario\nCuriosidades De Hackers\n\033[0m")
        print("\033[1;33mCofundadores\033[0m")
        print("\033[1;37mZunderrub\nCondorHacks\nLenam\n\033[0m")

        if verificar_imagen_existente(nombre_imagen):
            print("\033[1;32mLa máquina ya existe. Iniciando...\033[0m")
        else:
            descargar_imagen_docker_con_progreso(nombre_imagen)

        id_contenedor = iniciar_contenedor(nombre_imagen)

        obtener_ip_contenedor(id_contenedor)

        signal.signal(signal.SIGINT, manejar_salida)

        print("\033[1;31mPresiona Ctrl+C para detener la máquina\n\033[0m")

        signal.pause()

    except Exception as e:
        print(f"Ocurrió un error: {e}")
        sys.exit(1)
